prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>1643206756007669
,p_default_application_id=>104
,p_default_id_offset=>17112880843997265
,p_default_owner=>'EXT'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(793047221379817822)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
